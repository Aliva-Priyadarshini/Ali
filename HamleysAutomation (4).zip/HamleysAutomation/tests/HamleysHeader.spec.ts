import { test } from '@playwright/test';
import Logger from '../utils/Logger';
import { takeScreenshot} from '../utils/Screenshot';
import { TestCase01Page } from '../pages/TestCase01Page';
import { TestCase02Page } from '../pages/TestCase02Page';
import { TestCase03Page } from '../pages/TestCase03Page';
import { TestCase04Page } from '../pages/TestCase04Page';
import { TestCase05Page } from '../pages/TestCase05Page';
import { TestCase06Page } from '../pages/TestCase06Page';
import { TestCase07Page } from '../pages/TestCase07Page';
import { TestCase08Page } from '../pages/TestCase08Page';
import { TestCase09Page } from '../pages/TestCase09Page';
import { TestCase10Page } from '../pages/TestCase10Page';
import { TestCase11Page } from '../pages/TestCase11Page';
import { TestCase12Page } from '../pages/TestCase12Page';
import { TestCase13Page } from '../pages/TestCase13Page';
import { TestCase14Page } from '../pages/TestCase14Page';
import { TestCase15Page } from '../pages/TestCase15Page';
import { TestCase16Page } from '../pages/TestCase16Page';
import { TestCase17Page } from '../pages/TestCase17Page';
import { TestCase18Page } from '../pages/TestCase18Page';
import { TestCase19Page } from '../pages/TestCase19Page';
import { TestCase20Page } from '../pages/TestCase20Page';

test.describe('Hamleys Header Navigation Test Cases', () => {

  test('TC01 - Sale Art and Craft Navigation', async ({ page }) => {
    const testCase = new TestCase01Page(page);
    await testCase.execute();
  });

  test('TC02 - Sale Under 999 Navigation', async ({ page }) => {
    const testCase = new TestCase02Page(page);
    await testCase.execute();
  });

  test('TC03 - Sale 3 to 5 Years Navigation', async ({ page }) => {
    const testCase = new TestCase03Page(page);
    await testCase.execute();
  });

  test('TC04 - Clearance Sale Navigation', async ({ page }) => {
    const testCase = new TestCase04Page(page);
    await testCase.execute();
  });

  test('TC05 - Direct Sale Navigation', async ({ page }) => {
    const testCase = new TestCase05Page(page);
    await testCase.execute();
  });

  test('TC06 - Negative Sale Hover Behavior', async ({ page }) => {
    const testCase = new TestCase06Page(page);
    await testCase.execute();
  });

  test('TC07 - Return Gifts Under 500', async ({ page }) => {
    const testCase = new TestCase07Page(page);
    await testCase.execute();
  });

  test('TC08 - Return Gifts Under 1000', async ({ page }) => {
    const testCase = new TestCase08Page(page);
    await testCase.execute();
  });

  test('TC09 - Return Gifts Under 1500', async ({ page }) => {
    const testCase = new TestCase09Page(page);
    await testCase.execute();
  });

  test('TC10 - Return Gifts Negative Hover Behavior', async ({ page }) => {
    const testCase = new TestCase10Page(page);
    await testCase.execute();
  });

  test('TC11 - Login Navigation', async ({ page }) => {
    const testCase = new TestCase11Page(page);
    await testCase.execute();
  });

  test('TC12 - Login Redirect Parameter', async ({ page }) => {
    const testCase = new TestCase12Page(page);
    await testCase.execute();
  });

  test('TC13 - Repeated Login Navigation', async ({ page }) => {
    const testCase = new TestCase13Page(page);
    await testCase.execute();
  });

  test('TC14 - Login Negative Navigation', async ({ page }) => {
    const testCase = new TestCase14Page(page);
    await testCase.execute();
  });

  test('TC15 - Wishlist Navigation', async ({ page }) => {
    const testCase = new TestCase15Page(page);
    await testCase.execute();
  });

  test('TC16 - Unauthenticated Wishlist', async ({ page }) => {
    const testCase = new TestCase16Page(page);
    await testCase.execute();
  });

  test('TC17 - Wishlist Refresh and Back Navigation', async ({ page }) => {
    const testCase = new TestCase17Page(page);
    await testCase.execute();
  });

  test('TC18 - My Bag Navigation', async ({ page }) => {
    const testCase = new TestCase18Page(page);
    await testCase.execute();
  });

  test('TC19 - Empty Shopping Bag', async ({ page }) => {
    const testCase = new TestCase19Page(page);
    await testCase.execute();
  });

  test('TC20 - Add Sale Product to My Bag', async ({ page }) => {
    const testCase = new TestCase20Page(page);
    await testCase.execute();
  });

});