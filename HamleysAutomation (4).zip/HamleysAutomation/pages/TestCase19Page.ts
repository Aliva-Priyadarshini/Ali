import { Page, expect } from '@playwright/test';

export class TestCase19Page {
  constructor(private page: Page) {}

  async execute() {
    // Start with a clean browser session.
    await this.page.context().clearCookies();

    await this.page.goto('/');

    await this.page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });

    await this.page.reload();

    const myBag = this.page
      .getByRole('link', {
        name: /my bag/i
      })
      .first();

    await expect(myBag).toBeVisible();

    await myBag.click();

    await expect(this.page).toHaveURL(/cart\/bag/i);

    // Verify empty shopping bag message.
    const emptyBagMessage = this.page
      .getByText(/your shopping bag is empty/i)
      .first();

    await expect(emptyBagMessage).toBeVisible();

    // Verify Return To Homepage.
    const returnToHomepage = this.page
      .getByRole('link', {
        name: /return to homepage/i
      })
      .first();

    await expect(returnToHomepage).toBeVisible();

    await returnToHomepage.click();

    // Verify homepage.
    const sale = this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .first();

    await expect(sale).toBeVisible();

    // Open My Bag again.
    const myBagAgain = this.page
      .getByRole('link', {
        name: /my bag/i
      })
      .first();

    await expect(myBagAgain).toBeVisible();

    await myBagAgain.click();

    await expect(this.page).toHaveURL(/cart\/bag/i);

    // Verify bag is still empty.
    await expect(
      this.page
        .getByText(/your shopping bag is empty/i)
        .first()
    ).toBeVisible();

    await this.page.screenshot({
      path: 'screenshots/TC19.png',
      fullPage: true
    });
  }
}