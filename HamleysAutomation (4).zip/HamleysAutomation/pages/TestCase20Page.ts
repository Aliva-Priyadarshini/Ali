import { Page, expect } from '@playwright/test';

export class TestCase20Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(sale).toBeVisible();

    await sale.click();

    await expect(this.page).toHaveURL(
      /collection\/sale/i
    );

    const firstProduct = this.page
      .getByRole('link')
      .filter({
        hasText: /₹/,
        visible: true
      })
      .first();

    await expect(firstProduct).toBeVisible();

    await firstProduct.click();

    await this.page.waitForLoadState(
      'domcontentloaded'
    );

    const addToBag = this.page
      .getByText('Add to bag', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(addToBag).toBeVisible();

    await addToBag.click();

    await this.page.waitForTimeout(1000);

    const myBag = this.page
      .getByText('My bag', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(myBag).toBeVisible();

    await myBag.click();

    await expect(this.page).toHaveURL(
      /cart\/bag/i
    );

    const emptyBagMessage = this.page
      .getByText(
        'Your Shopping Bag is empty',
        {
          exact: true
        }
      )
      .filter({
        visible: true
      });

    await expect(
      emptyBagMessage
    ).toHaveCount(0);

    await this.page.reload();

    await expect(this.page).toHaveURL(
      /cart\/bag/i
    );

    const emptyAfterRefresh = this.page
      .getByText(
        'Your Shopping Bag is empty',
        {
          exact: true
        }
      )
      .filter({
        visible: true
      });

    await expect(
      emptyAfterRefresh
    ).toHaveCount(0);

    await this.page.screenshot({
      path: 'screenshots/TC20.png',
      fullPage: true
    });
  }
}