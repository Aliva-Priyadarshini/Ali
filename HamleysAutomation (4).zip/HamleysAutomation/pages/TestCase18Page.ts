import { Page, expect } from '@playwright/test';

export class TestCase18Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const myBag = this.page
      .getByRole('link', {
        name: /my bag/i
      })
      .first();

    await expect(myBag).toBeVisible();

    await expect(myBag).toBeEnabled();

    await myBag.click();

    await expect(this.page).toHaveURL(/cart\/bag/i);

    await this.page.waitForLoadState(
      'domcontentloaded'
    );

    await expect(
      this.page.getByText(/shopping bag/i).first()
    ).toBeVisible();

    await expect(
      this.page.getByText(/404|server error/i)
    ).toHaveCount(0);

    await this.page.reload();

    await expect(this.page).toHaveURL(/cart\/bag/i);

    await this.page.goBack();

    const myBagAgain = this.page
      .getByRole('link', {
        name: /my bag/i
      })
      .first();

    await expect(myBagAgain).toBeVisible();

    await myBagAgain.click();

    await expect(this.page).toHaveURL(/cart\/bag/i);
  }
}