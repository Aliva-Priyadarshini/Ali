import { Page, expect } from '@playwright/test';

export class TestCase10Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const originalUrl = this.page.url();

    const returnGifts = this.page
      .getByRole('link', {
        name: 'Return Gifts',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(returnGifts).toBeVisible();

    await returnGifts.hover();

    const under500 = this.page
      .getByRole('link', {
        name: 'Under 500',
        exact: true
      })
      .filter({
        visible: true
      });

    const under1000 = this.page
      .getByRole('link', {
        name: 'Under 1000',
        exact: true
      })
      .filter({
        visible: true
      });

    const under1500 = this.page
      .getByRole('link', {
        name: 'Under 1500',
        exact: true
      })
      .filter({
        visible: true
      });

    const shopAll = this.page
      .getByRole('link', {
        name: 'Shop All',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(under500).toBeVisible();
    await expect(under1000).toBeVisible();
    await expect(under1500).toBeVisible();
    await expect(shopAll).toBeVisible();

    await this.page.mouse.move(5, 700);

    expect(this.page.url()).toBe(originalUrl);

    await returnGifts.hover();

    const shopAllAgain = this.page
      .getByRole('link', {
        name: 'Shop All',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(shopAllAgain).toBeVisible();

    await shopAllAgain.click();

    await expect(this.page).toHaveURL(
      /buy-return-gift-for-kids-online/i
    );
  }
}