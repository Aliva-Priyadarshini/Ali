import { Page, expect } from '@playwright/test';

export class TestCase12Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const login = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(login).toBeVisible();

    await login.click();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    const currentUrl = this.page.url();

    expect(currentUrl).toContain(
      '/auth/login'
    );

    expect(currentUrl).toContain(
      'redirectUrl'
    );

    await this.page.reload();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    await this.page.goBack();

    const loginAgain = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(loginAgain).toBeVisible();

    await loginAgain.click();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    await this.page.goBack();
  }
}