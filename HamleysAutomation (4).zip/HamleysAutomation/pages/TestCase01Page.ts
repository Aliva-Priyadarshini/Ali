import { Page, expect } from '@playwright/test';

export class TestCase01Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({ visible: true });

    await expect(sale).toBeVisible();

    await sale.hover();

    const shopByCategory = this.page
      .getByText(/shop by category/i)
      .filter({ visible: true });

    await expect(shopByCategory).toBeVisible();

    const artAndCraft = this.page
      .getByRole('link', {
        name: /art.*craft/i
      })
      .filter({ visible: true });

    await expect(artAndCraft).toBeVisible();

    await artAndCraft.click();

    await expect(this.page).toHaveURL(
      /art--craft|deals-on-art-craft/i
    );

    const firstProduct = this.page
      .getByRole('link')
      .filter({
        hasText: /₹/,
        visible: true
      })
      .first();

    await expect(firstProduct).toBeVisible();

    await firstProduct.click();

    await expect(
      this.page
        .getByText(/₹/)
        .filter({ visible: true })
        .first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({ visible: true })
      .hover();

    await this.page
      .getByRole('link', {
        name: /shop all/i
      })
      .filter({ visible: true })
      .click();

    await expect(this.page).toHaveURL(
      /collection\/sale/i
    );
  }
}
