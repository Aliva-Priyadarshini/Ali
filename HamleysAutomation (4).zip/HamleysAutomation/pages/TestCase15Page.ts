import { Page, expect } from '@playwright/test';

export class TestCase15Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const wishlist = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlist).toBeVisible();

    await wishlist.click();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.reload();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.goBack();

    const wishlistAgain = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlistAgain).toBeVisible();

    await wishlistAgain.click();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.screenshot({
      path: 'screenshots/TC15.png',
      fullPage: true
    });
  }
}