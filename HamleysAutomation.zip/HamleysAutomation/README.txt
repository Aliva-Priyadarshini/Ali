1. Open this folder in VS Code.
2. Open terminal in the HamleysAutomation folder.
3. Run: npm install
4. Run: npx playwright install chromium
5. Run: npx playwright test --list
6. Run: npx playwright test --headed

Add TestCase02Page.ts through TestCase20Page.ts under pages/, then import them in tests/HamleysHeader.spec.ts.
