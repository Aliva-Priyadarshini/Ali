import { Page, expect } from '@playwright/test';

export class TestCase14Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const homepageUrl = this.page.url();

    const login = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(login).toBeVisible();

    await login.click();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    const loginUrl = this.page.url();

    expect(loginUrl).not.toBe(
      homepageUrl
    );

    expect(loginUrl).not.toContain(
      '/wishlist'
    );

    expect(loginUrl).not.toContain(
      '/cart/bag'
    );

    expect(loginUrl).toContain(
      '/auth/login'
    );

    await this.page.goBack();

    const wishlist = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlist).toBeVisible();

    const myBag = this.page
      .getByText('My bag', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(myBag).toBeVisible();
  }
}