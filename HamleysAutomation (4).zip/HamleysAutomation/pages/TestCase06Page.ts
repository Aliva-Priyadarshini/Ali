import { Page, expect } from '@playwright/test';

export class TestCase06Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(sale).toBeVisible();

    await sale.hover();

    const shopByCategory = this.page
      .getByText('Shop By Category', {
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(shopByCategory).toBeVisible();

    await this.page.mouse.move(5, 700);

    await expect(shopByCategory).not.toBeVisible();

    await sale.hover();

    const artAndCraft = this.page
      .getByRole('link', {
        name: 'Art & Craft',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(artAndCraft).toBeVisible();

    await artAndCraft.hover();

    await this.page.mouse.move(5, 700);

    await expect(sale).toBeVisible();

    await sale.click();

    await expect(this.page).toHaveURL(
      /collection\/sale/i
    );

    await this.page.goBack();

    await expect(
      this.page.getByText(/404|server error/i)
    ).toHaveCount(0);

    const saleAfterBack = this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({
        visible: true
      });

    await expect(saleAfterBack).toBeVisible();
  }
}