import { Page, expect } from '@playwright/test';

export class TestCase02Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', { name: 'Sale', exact: true })
      .first();

    await expect(sale).toBeVisible();

    await sale.hover();

    const shopByPrice = this.page
      .getByText(/shop by price/i)
      .first();

    await expect(shopByPrice).toBeVisible();

    const under999 = this.page
      .getByRole('link', { name: /under 999/i })
      .first();

    await expect(under999).toBeVisible();

    await under999.click();

    await expect(this.page).toHaveURL(/under-1000/i);

    const firstProduct = this.page
      .getByRole('link')
      .filter({ hasText: /₹/ })
      .first();

    await expect(firstProduct).toBeVisible();

    await firstProduct.click();

    await expect(
      this.page.getByText(/₹/).first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page.reload();

    await expect(this.page).toHaveURL(/under-1000/i);
  }
}