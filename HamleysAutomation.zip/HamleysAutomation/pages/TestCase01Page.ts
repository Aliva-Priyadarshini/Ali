import { Page, expect } from '@playwright/test';
export class TestCase01Page {
  constructor(private page: Page) {}
  async execute() {
    await this.page.goto('/');
    const sale = this.page.getByRole('link', { name: 'Sale', exact: true }).first();
    await expect(sale).toBeVisible();
    await sale.hover();
    await expect(this.page.getByText(/shop by category/i).first()).toBeVisible();
  }
}
