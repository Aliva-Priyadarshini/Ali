import { Page, expect } from '@playwright/test';

export class TestCase17Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    let wishlist = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlist).toBeVisible();

    await wishlist.click();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.reload();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.goBack();

    wishlist = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlist).toBeVisible();

    await wishlist.click();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.goBack();

    await this.page.mouse.wheel(
      0,
      800
    );

    await this.page.mouse.wheel(
      0,
      -800
    );

    wishlist = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlist).toBeVisible();

    await wishlist.click();

    await expect(this.page).toHaveURL(
      /wishlist/i
    );

    await this.page.screenshot({
      path: 'screenshots/TC17.png',
      fullPage: true
    });
  }
}