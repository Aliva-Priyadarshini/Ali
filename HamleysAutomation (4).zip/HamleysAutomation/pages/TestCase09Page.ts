import { Page, expect } from '@playwright/test';

export class TestCase09Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const returnGifts = this.page
      .getByRole('link', {
        name: 'Return Gifts',
        exact: true
      })
      .first();

    await expect(returnGifts).toBeVisible();

    await returnGifts.hover();

    const under1500 = this.page
      .getByRole('link', {
        name: /under 1500/i
      })
      .first();

    await expect(under1500).toBeVisible();

    await under1500.click();

    await expect(this.page).toHaveURL(/under-1500/i);

    const firstProduct = this.page
      .getByRole('link')
      .filter({ hasText: /₹/ })
      .first();

    await expect(firstProduct).toBeVisible();

    await this.page.mouse.wheel(0, 700);

    await firstProduct.click();

    await expect(
      this.page.getByText(/₹/).first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page.reload();

    await expect(
      this.page.getByText(/404|server error/i)
    ).toHaveCount(0);
  }
}