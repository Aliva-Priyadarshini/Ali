import { Page, expect } from '@playwright/test';

export class TestCase16Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.context().clearCookies();

    await this.page.goto('/');

    await this.page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });

    await this.page.reload();

    const wishlist = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlist).toBeVisible();

    await wishlist.click();

    const currentUrl = this.page.url();

    const wishlistOpened =
      currentUrl.includes('/wishlist');

    const loginOpened =
      currentUrl.includes('/auth/login');

    expect(
      wishlistOpened || loginOpened
    ).toBeTruthy();

    await this.page.reload();

    await expect(
      this.page.getByText(/404|server error/i)
    ).toHaveCount(0);

    await this.page.goto('/');

    const wishlistAgain = this.page
      .getByText('Wishlist', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(wishlistAgain).toBeVisible();
  }
}