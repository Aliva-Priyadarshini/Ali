import { Page, expect } from '@playwright/test';

export class TestCase03Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({ visible: true });

    await sale.hover();

    const shopByAge = this.page
      .getByText(/shop by age/i)
      .filter({ visible: true });

    await expect(shopByAge).toBeVisible();

    const ageThreeToFive = this.page
      .getByRole('link', {
        name: /3 to 5 years/i
      })
      .filter({ visible: true });

    await expect(ageThreeToFive).toBeVisible();

    await ageThreeToFive.click();

    await expect(this.page).toHaveURL(
      /3-to-5-years/i
    );

    const firstProduct = this.page
      .getByRole('link')
      .filter({
        hasText: /₹/,
        visible: true
      })
      .first();

    await expect(firstProduct).toBeVisible();

    await this.page.mouse.wheel(0, 600);

    await firstProduct.click();

    await expect(
      this.page
        .getByText(/₹/)
        .filter({ visible: true })
        .first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page
      .getByRole('link', {
        name: 'Sale',
        exact: true
      })
      .filter({ visible: true })
      .hover();
  }
}