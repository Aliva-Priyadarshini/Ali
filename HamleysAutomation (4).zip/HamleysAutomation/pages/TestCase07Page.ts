import { Page, expect } from '@playwright/test';

export class TestCase07Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const returnGifts = this.page
      .getByRole('link', {
        name: 'Return Gifts',
        exact: true
      })
      .first();

    await expect(returnGifts).toBeVisible();

    await returnGifts.hover();

    const under500 = this.page
      .getByRole('link', {
        name: /under 500/i
      })
      .first();

    await expect(under500).toBeVisible();

    await under500.click();

    await expect(this.page).toHaveURL(/under-500/i);

    const firstProduct = this.page
      .getByRole('link')
      .filter({ hasText: /₹/ })
      .first();

    await expect(firstProduct).toBeVisible();

    await firstProduct.click();

    await expect(
      this.page.getByText(/₹/).first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page.reload();

    await expect(this.page).toHaveURL(/under-500/i);

    await this.page.screenshot({
      path: 'screenshots/TC07.png',
      fullPage: true
    });
  }
}