import { Page, expect } from '@playwright/test';

export class TestCase13Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const loginFirst = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(loginFirst).toBeVisible();

    await loginFirst.click();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    await this.page.goBack();

    const loginSecond = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(loginSecond).toBeVisible();

    await loginSecond.click();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    await this.page.goBack();

    const loginThird = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(loginThird).toBeVisible();

    await loginThird.click();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    await expect(
      this.page.getByText(/404|server error/i)
    ).toHaveCount(0);

    await this.page.reload();

    await expect(this.page).toHaveURL(
      /auth\/login/i
    );

    await this.page.goBack();

    const loginAfterBack = this.page
      .getByText('Login', {
        exact: true
      })
      .filter({
        visible: true
      })
      .first();

    await expect(loginAfterBack).toBeVisible();

    await this.page.screenshot({
      path: 'screenshots/TC13.png',
      fullPage: true
    });
  }
}