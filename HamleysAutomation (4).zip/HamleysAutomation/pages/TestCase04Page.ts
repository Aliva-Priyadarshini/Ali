import { Page, expect } from '@playwright/test';

export class TestCase04Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', { name: 'Sale', exact: true })
      .first();

    await expect(sale).toBeVisible();

    await sale.hover();

    const clearanceSale = this.page
      .getByRole('link', { name: /clearance sale/i })
      .first();

    await expect(clearanceSale).toBeVisible();

    await clearanceSale.click();

    await expect(this.page).toHaveURL(/clearance-sale/i);

    const firstProduct = this.page
      .getByRole('link')
      .filter({ hasText: /₹/ })
      .first();

    await expect(firstProduct).toBeVisible();

    await this.page.mouse.wheel(0, 600);

    await firstProduct.click();

    await expect(
      this.page.getByText(/₹/).first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page.reload();

    await expect(
      this.page.getByText(/404|server error/i)
    ).toHaveCount(0);
  }
}