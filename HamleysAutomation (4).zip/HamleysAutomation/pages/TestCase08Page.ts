import { Page, expect } from '@playwright/test';

export class TestCase08Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const returnGifts = this.page
      .getByRole('link', {
        name: 'Return Gifts',
        exact: true
      })
      .first();

    await expect(returnGifts).toBeVisible();

    await returnGifts.hover();

    const under1000 = this.page
      .getByRole('link', {
        name: /under 1000/i
      })
      .first();

    await expect(under1000).toBeVisible();

    await expect(under1000).toBeEnabled();

    await under1000.click();

    await expect(this.page).toHaveURL(/under-1000/i);

    const firstProduct = this.page
      .getByRole('link')
      .filter({ hasText: /₹/ })
      .first();

    await expect(firstProduct).toBeVisible();

    await firstProduct.click();

    await expect(
      this.page.getByText(/₹/).first()
    ).toBeVisible();

    await this.page.goBack();

    await this.page.mouse.wheel(0, 700);

    await this.page.goto('/');

    const returnGiftsAgain = this.page
      .getByRole('link', {
        name: 'Return Gifts',
        exact: true
      })
      .first();

    await expect(returnGiftsAgain).toBeVisible();
  }
}