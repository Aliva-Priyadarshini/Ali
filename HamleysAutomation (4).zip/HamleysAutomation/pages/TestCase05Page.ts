import { Page, expect } from '@playwright/test';

export class TestCase05Page {
  constructor(private page: Page) {}

  async execute() {
    await this.page.goto('/');

    const sale = this.page
      .getByRole('link', { name: 'Sale', exact: true })
      .first();

    await expect(sale).toBeVisible();

    await expect(sale).toBeEnabled();

    await sale.click();

    await expect(this.page).toHaveURL(
      /collection\/sale/i
    );

    const firstProduct = this.page
      .getByRole('link')
      .filter({ hasText: /₹/ })
      .first();

    await expect(firstProduct).toBeVisible();

    await expect(
      this.page.getByText(/₹/).first()
    ).toBeVisible();

    await this.page.mouse.wheel(0, 1000);

    await this.page.mouse.wheel(0, -1000);

    await this.page.goto('/');

    const saleAgain = this.page
      .getByRole('link', { name: 'Sale', exact: true })
      .first();

    await expect(saleAgain).toBeVisible();
  }
}