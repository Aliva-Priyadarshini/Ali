import { test } from '@playwright/test';
import { TestCase01Page } from '../pages/TestCase01Page';

test.describe('Hamleys Header Navigation', () => {
  test('TC01 - Sale Art & Craft', async ({ page }) => {
    await new TestCase01Page(page).execute();
  });
});
